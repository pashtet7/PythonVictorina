name = "Паша"
school_clas = 11
age = 18
excellent_student = False
average_rating = 4.4

print (type(name))
print (type(school_clas))
print (type(age))
print (type(excellent_student))
print (type(average_rating))

