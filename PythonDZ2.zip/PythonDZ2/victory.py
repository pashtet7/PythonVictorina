error =  0
correct = 0
answer = input("хотите начать Викторину?")

if answer == "нет":
    print("Хорошо, удачного вам дня ")

else:
    while answer == "да":
        print("Добро пожаловать в викторину по футболистам!!!")
        yashin = int(input("Введите год рождения Л.И Яшина"))
        # Ответ 1929
        if yashin  == 1929:
            correct += 1
            print("Принято! Идем дальше")
        else:
            error += 1
            print("Принято! Идем дальше")
        # Ответ 1940
        pele = int(input("Введите год рождения Пеле"))
        if pele  == 1940:
            correct += 1
            print("Принято! Идем дальше")
        else:
            error += 1
            print("Принято! Идем дальше")
        # Ответ 1985
        ronaldo = int(input("Введите год рождения Роналду"))
        if ronaldo  == 1985:
            correct += 1
            print("Принято! Идем дальше")
        else:
            error += 1
            print("Принято! Идем дальше")
        # Ответ 1987
        messi = int(input("Введите год рождения Месси"))
        if messi == 1987:
            correct += 1
            print("Принято! Идем дальше")
        else:
            error += 1
            print("Принято! Идем дальше")

        # Ответ 1960
        Maradona = int(input("Введите год рождения Марадонны"))
        if pele  == 1960:
            correct += 1
            print("Принято! Идем дальше")
        else:
            error += 1
            print("Принято! Идем дальше")

        print("Молодец, твоё число правельных ответов: ",correct)
        print("Твоё число правельных ответов: ",error)
        print("Твоё % правельных ответов: ",correct * 100 / 5)
        print("Твоё % Неправельных ответов: ",error * 100 / 5)

        answer = input("хотите начать Викторину заново?")

print("Хорошо, удачного вам дня ")


