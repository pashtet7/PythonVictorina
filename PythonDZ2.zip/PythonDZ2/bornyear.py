year_of_birth = int(input("Напишите год рождение А.С Пушкина: "))
if year_of_birth == 1799:
    print("верно")
elif year_of_birth != 1799:
    print("Неверно")
