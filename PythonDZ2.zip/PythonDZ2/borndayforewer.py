year_of_birth = int(input("Напишите год рождение А.С Пушкина: "))
if year_of_birth != 1799:
    while year_of_birth != 1799:
        if year_of_birth != 1799:
            print("Неверно попробуйте снова")
            year_of_birth = int(input("Напишите год рождение А.С Пушкина: "))


day_brith = int(input("Введите день рождения A.C Пушкина: "))
if day_brith != 6:
    while day_brith != 6:
        if day_brith != 6:
            print("Неверно попробуйте снова")
            day_brith = int(input("Введите день рождения A.C Пушкина: "))

print("Все Верно")