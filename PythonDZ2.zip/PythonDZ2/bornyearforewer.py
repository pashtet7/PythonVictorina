year_of_birth = int(input("Напишите год рождение А.С Пушкина: "))
if year_of_birth == 1799:
    print("верно")
else:
    while year_of_birth != 1799:
        if year_of_birth != 1799:
            print("Неверно попробуйте снова")
            year_of_birth = int(input("Напишите год рождение А.С Пушкина: "))

print("Верно")