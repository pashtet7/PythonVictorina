year_of_birth = int(input("Напишите год рождение А.С Пушкина: "))
if year_of_birth == 1799:
    day_brith = int(input("Введите день рождения A.C Пушкина: "))
    if day_brith == 6:
        print("Верно")
    else:
        print("Неверный день")

else:
    print("Неверный год")


